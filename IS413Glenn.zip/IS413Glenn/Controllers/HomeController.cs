﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using IS413Glenn.Models;

namespace IS413Glenn.Controllers
{
    public class HomeController : Controller
    {
        private IQuoteRepository repo;

        public HomeController (IQuoteRepository temp)
        {
            repo = temp;
        }

        [HttpGet]
        public IActionResult Index()
        { 
            var blah = repo.Quotes.ToList();
            return View(blah);
        }


        [HttpPost]
        public IActionResult QuoteDetails(Quote q)
        {
            //not sure how to make this work
            var SingleQuote = q;
            return View(SingleQuote);
        }

        [HttpGet]
        public IActionResult AddQuote()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddQuote(Quote q)
        {
            //save changes to database

            return RedirectToAction("Index");
        }

    }
}
