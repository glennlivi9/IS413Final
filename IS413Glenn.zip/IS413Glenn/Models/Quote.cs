﻿using System;
using System.ComponentModel.DataAnnotations;

namespace IS413Glenn.Models
{
    public class Quote
    {
        [Key]
        [Required]
        public int QuoteID { get; set; }
        [Required]
        public string QuoteText { get; set; }
        [Required]
        public string QuoteAuthor { get; set; }

        public string QuoteDate { get; set; }
        public string QuoteSubject { get; set; }
        public string QuoteCitation { get; set; }


   
    }
}
