﻿using System;
using System.Linq;

namespace IS413Glenn.Models
{
    public interface IQuoteRepository
    {
        IQueryable<Quote> Quotes { get; }
    }
}
