﻿using System;
using Microsoft.EntityFrameworkCore;

namespace IS413Glenn.Models
{
    public class QuoteContext : DbContext
    {
        public QuoteContext()
        {
        }

        public QuoteContext(DbContextOptions<QuoteContext>  options)
            : base(options)
        {

        }

        public DbSet<Quote> Quotes { get; set; }
    }
}
