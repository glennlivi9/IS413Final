﻿using System;
using System.Linq;

namespace IS413Glenn.Models
{
    public class EFQuoteRepository : IQuoteRepository
    {
        private QuoteContext context { get; set; }

        public EFQuoteRepository (QuoteContext temp)
        {
            context = temp;
        }

        public IQueryable<Quote> Quotes => context.Quotes;
    }
}
